<!DOCTYPE html>
<html>
<head>
    <title>Web Review</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\web_shela\resources\views/layout.blade.php ENDPATH**/ ?>