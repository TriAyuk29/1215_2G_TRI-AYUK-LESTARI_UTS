@extends('layout')
  
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div>
                <h2>Review</h2>
            </div>
            <div>
                <a class="btn btn-primary" href="{{ route('stoks.index') }}"> Back</a>
            </div>
        </div>
    </div>
   
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Barang :</strong>
                {{ $stok->barang }}
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Review :</strong>
                {{ $stok->review }}
            </div>
        </div>
    </div>
@endsection