@extends('layout')
 
@section('content')
    <div class="row mt-5">
        <div class="col-lg-12 margin-tb">
            <div class="float-start">
                <h2>Web Review Barang</h2>
            </div>
            <div class="float-end">
                <a class="btn btn-success" href="{{ route('stoks.create') }}">Isi Review</a>
            </div>
        </div>
    </div>
   
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
   
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Barang</th>
            <th>Review</th>
            <th width="280px">Action</th>
        </tr>
        @foreach ($stoks as $stok)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $stok->barang }}</td>
            <td>{{ $stok->review }}</td>
            <td>
                <form action="{{ route('stoks.destroy',$stok->id) }}" method="POST">
   
                    <a class="btn btn-info" href="{{ route('stoks.show',$stok->id) }}">Show</a>
    
                    <a class="btn btn-primary" href="{{ route('stoks.edit',$stok->id) }}">Edit</a>
   
                    @csrf
                    @method('DELETE')
      
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>
    <div class="row text-center">
        {!! $stoks->links() !!}
    </div>
      
@endsection